#import "/src/lib.typ": video-svg, audio-svg

#let embed-local-media = true
#let allow-remote-media = true

#set page(
  paper: "a4",
  margin: 1.8cm,
)

#set document(
  title: "media-svg demo",
  description: "Demonstration of the media-svg Typst package for embedding playable video and audio in SVG output.",
)

#show heading.where(level: 1): it => block(
  align(center)[
    #text(size: 24pt, weight: "bold")[#it.body]
  ],
  below: 2.4em,
)

#show heading.where(level: 2): it => block(
  align(center)[
    #text(size: 18pt, weight: "bold")[#it.body]
  ],
  above: 1.2em,
  below: 1.6em,
)

#set text(
  font: "Libertinus Serif",
  size: 10pt,
  lang: "en",
)

#set par(
  leading: 0.65em,
  spacing: 0.75em,
  justify: true,
)

#set heading(numbering: none)

#show raw.where(block: true): block.with(
  fill: rgb("#f6f6f8"),
  inset: 8pt,
  radius: 4pt,
  width: 100%,
)

#show raw.where(block: false): box.with(
  fill: rgb("#f1f1f3"),
  inset: (x: 3pt, y: 0pt),
  outset: (y: 3pt),
  radius: 2pt,
)

= media-svg demo

#grid(
  columns: (1fr, 1fr),
  column-gutter: 1.5em,
  align: horizon,
  [
    `media-svg` embeds playable HTML5 video and audio in SVG output.

    Sources may be remote URLs, local file paths, or raw `data:` URLs. The media policy is explicit:

    - `embed-local` controls local paths and `data:` URLs
    - `allow-remote` controls `http://` and `https://` URLs
    - blocked media shows the poster or fallback instead

    This demo is designed for #link("https://texlyre.org")[TeXlyre], which renders SVG+XML through a patched #link("https://github.com/TeXlyre/typst.ts")[`typst.ts`].
  ],
  layout(size => {
    let w = int(size.width / 1pt)
    let h = int(w * 9 / 16)
    let flower-url = read("/examples/assets/flower.dataurl").trim()

    video-svg(
      flower-url,
      poster: "/examples/assets/fallback-flower.png",
      width: w,
      height: h,
      loop: true,
      controls: true,
      title: "Flower video",
      description: "Looping demo clip of a flower.",
      lang: "en",
      embed-local: embed-local-media,
      allow-remote: allow-remote-media,
    )
  }),
)

== Quick start

Import the public functions:

```typ
//#import "@preview/media-svg:0.1.0": video-svg, audio-svg
#import "/src/lib.typ": video-svg, audio-svg

#let embed-local-media = true
#let allow-remote-media = true
```

Use `video-svg` and `audio-svg` with an explicit media policy:

```typ
#video-svg("https://upload.wikimedia.org/wikipedia/commons/e/e7/Big_buck_bunny_720p_5mb.webm",
  width: 640,
  height: 360,
  loop: true,
  controls: true,
  title: "Big Buck Bunny clip",
  description: "30-second 720p clip from the Blender Foundation's open animated film.",
  lang: "en",
  embed-local: embed-local-media,
  allow-remote: allow-remote-media,
)

#audio-svg("https://upload.wikimedia.org/wikipedia/commons/e/e1/Kimiko_Ishizaka_-_Bach_-_Well-Tempered_Clavier,_Book_1_-_02_Fugue_No._1_in_C_major,_BWV_846.ogg",
  width: 480,
  height: 60,
  title: "Bach Fugue No. 1 in C major, BWV 846",
  description: "Performed by Kimiko Ishizaka, public domain.",
  lang: "en",
  embed-local: embed-local-media,
  allow-remote: allow-remote-media,
)
```

Local examples use files from `/examples/assets/`.

#pagebreak()

== API

Both functions take a source string and options. The source can be:

- a remote `http://` or `https://` URL
- a local file path
- a raw `data:` URL

`embed-local` controls local file paths and raw `data:` URLs. When `embed-local` is `false`, those sources are removed and the poster or fallback is shown.

`allow-remote` controls remote `http://` and `https://` URLs. When `allow-remote` is `false`, those sources are removed and the poster or fallback is shown.

#v(1em)

Shared arguments:

- `src` (str): media source. Can be a remote URL, local file path, or raw `data:` URL.
- `width`, `height` (int): SVG/player dimensions in pixels. Defaults differ by function.
- `controls` (bool): show native playback controls. Default `true`.
- `autoplay` (bool): start playing on load. Defaults differ by function. Video autoplay usually requires `muted: true`.
- `muted` (bool): start muted. Defaults differ by function.
- `loop` (bool): restart at end. Defaults differ by function.
- `preload` (str): browser preload hint, such as `"none"`, `"metadata"`, or `"auto"`. Defaults differ by function.
- `crossorigin` (str or none): CORS mode for the media element. Set to `none` if the host does not send compatible CORS headers. Default `"anonymous"`.
- `background` (str): CSS color for the embedded media wrapper. Defaults differ by function.
- `background-color` (str): Typst hex color for the posterless fallback placeholder. Default `"#f0f0f3"`.
- `color` (str): Typst hex color for the fallback icon and label. Default `"#444444"`.
- `poster` (str or none): path to a thumbnail layered above the player. Default `none`.
- `poster-link` (str, none, or auto): URL the poster or fallback links to. With `auto`, links to `src` only when `src` is remote and `allow-remote` is `true`; otherwise no link. Default `auto`.
- `fallback` (bool): when no `poster` is set, render a placeholder with an icon and the `title`/`description`. Also shown when the source is blocked by `embed-local: false` or `allow-remote: false`. Default `true`.
- `title` (str or none): short label announced by screen readers and shown in the fallback. Default `none`.
- `description` (str or none): longer description for assistive tech, PDF tags, and the fallback. Default `none`.
- `lang` (str or none): BCP 47 language code, such as `"en"` or `"de"`. Default `none`.
- `embed-local` (bool): allow local file paths and raw `data:` URLs to be embedded. Set to `false` to remove local/data media and show the poster or fallback. Default `true`.
- `allow-remote` (bool): allow remote `http://` and `https://` sources in the generated SVG. Set to `false` to remove remote media and show the poster or fallback. Default `true`.

#v(0.5em)

`video-svg(src, ...)` defaults and video-only arguments:

- `width`, `height`: default `640`, `360`.
- `autoplay`: default `true`.
- `muted`: default `true`.
- `loop`: default `true`.
- `preload`: default `"auto"`.
- `background`: default `"black"`.
- `playsinline` (bool): play inline on iOS rather than opening fullscreen playback. Default `true`.
- `object-fit` (str): CSS object fit for the video. Common values are `"cover"`, `"contain"`, `"fill"`, `"none"`, and `"scale-down"`. Default `"cover"`.
- `stretch` (int): pixels to overscan, hiding thin black edges from some encoders. Default `4`.

#v(0.5em)

`audio-svg(src, ...)` defaults and audio-only notes:

- `width`, `height`: default `320`, `54`.
- `autoplay`: default `false`.
- `muted`: default `false`.
- `loop`: default `false`.
- `preload`: default `"metadata"`.
- `background`: default `"transparent"`.
- `fallback`: the audio fallback is a bar with a music note and label.

#pagebreak()

== Accessibility

Pass `title`, `description`, and `lang` whenever the media carries meaning.

```typ
#video-svg("/examples/assets/flower.mp4",
  poster: "/examples/assets/fallback-flower.png",
  width: 640,
  height: 360,
  title: "Flower video",
  description: "A close-up of a yellow flower swaying in a light breeze.",
  lang: "en",
  embed-local: true,
  allow-remote: true,
)
```

The package writes SVG accessibility metadata and passes the description as PDF alt text. Without these fields, the SVG may be announced only as a generic graphic.

#v(1em)

If the media source is blocked by `embed-local: false` or `allow-remote: false`, the poster or fallback remains visible.

#v(4em)

== Compatibility

Playable media appears in SVG output rendered by a browser or browser-like environment that preserves embedded SVG/XML media markup.

PDF output and static renderers show the poster or fallback placeholder.

Remote playback depends on browser support, network access, MIME type, codec support, CORS behavior, and `allow-remote`.

Local and `data:` media depend on `embed-local`.

#pagebreak()

== Remote URL

Remote media is referenced by URL and fetched by the browser, not by Typst. It is included only when `allow-remote` is `true`. If `allow-remote` is `false`, the media source is removed and the poster or fallback is shown.

#layout(size => {
  let gap = 12pt
  let cell-w = (size.width - gap) / 2
  let w = int(cell-w / 1pt)
  let h = int(w * 9 / 16)

  grid(
    columns: (1fr, 1fr),
    gutter: gap,

    [
      #video-svg("https://upload.wikimedia.org/wikipedia/commons/e/e7/Big_buck_bunny_720p_5mb.webm",
        poster: "/examples/assets/fallback-bbbunny.png",
        width: w,
        height: h,
        loop: true,
        controls: true,
        preload: "metadata",
        title: "Big Buck Bunny clip",
        description: "30-second 720p clip from the Blender Foundation's open animated film.",
        lang: "en",
        embed-local: embed-local-media,
        allow-remote: true,
      )

      #parbreak()
      #text(size: 9pt)[`allow-remote: true` keeps the remote video URL.]
    ],

    [
      #video-svg("https://upload.wikimedia.org/wikipedia/commons/e/e7/Big_buck_bunny_720p_5mb.webm",
        poster: "/examples/assets/fallback-bbbunny.png",
        width: w,
        height: h,
        loop: true,
        controls: true,
        preload: "metadata",
        title: "Big Buck Bunny clip",
        description: "30-second 720p clip from the Blender Foundation's open animated film.",
        lang: "en",
        embed-local: embed-local-media,
        allow-remote: false,
      )

      #parbreak()
      #text(size: 9pt)[`allow-remote: false` removes the URL and shows the poster.]
    ],
  )
})

```typ
#video-svg("https://example.com/video.webm",
  poster: "/examples/assets/fallback.png",
  width: 640,
  height: 360,
  controls: true,
  title: "Remote video",
  description: "A remotely hosted video.",
  lang: "en",
  embed-local: false,
  allow-remote: true,
)
```

Use `embed-local: false` with remote URLs when you want to guarantee that no local or `data:` payload is embedded. Use `allow-remote: false` when you want the same call to degrade to its poster or fallback without keeping the remote media URL.

#pagebreak()

== Local file

Local files are read and inlined only when `embed-local` is `true`.

#layout(size => {
  let w = int(size.width / 1pt)
  let h = int(w * 9 / 16)

  video-svg("/examples/assets/flower.mp4",
    width: w,
    height: h,
    loop: true,
    controls: true,
    title: "Flower video",
    description: "Looping demo clip of a flower.",
    lang: "en",
    embed-local: embed-local-media,
    allow-remote: allow-remote-media,
  )
})

```typ
#video-svg("/examples/assets/flower.mp4",
  width: w,
  height: h,
  loop: true,
  controls: true,
  title: "Flower video",
  description: "Looping demo clip of a flower.",
  lang: "en",
  embed-local: true,
  allow-remote: true,
)
```

For large files, prebuild a sidecar `data:` URL:

```sh
{ printf 'data:video/mp4;base64,'; base64 -w 0 flower.mp4; } > flower.dataurl
```

Then read and pass it:

```typ
#let flower-url = read("/examples/assets/flower.dataurl").trim()

#video-svg(
  flower-url,
  poster: "/examples/assets/fallback-flower.png",
  width: 640,
  height: 360,
  title: "Flower video",
  description: "Looping demo clip of a flower.",
  lang: "en",
  embed-local: true,
)
```

A `data:` URL is treated as embedded local media. It is removed when `embed-local` is `false`.

#pagebreak()

== Audio

Audio supports the same source modes and policy flags.

#layout(size => {
  let w = int(size.width / 1pt)

  audio-svg("https://upload.wikimedia.org/wikipedia/commons/e/e1/Kimiko_Ishizaka_-_Bach_-_Well-Tempered_Clavier,_Book_1_-_02_Fugue_No._1_in_C_major,_BWV_846.ogg",
    width: w,
    height: 70,
    preload: "metadata",
    title: "Bach Fugue No. 1 in C major, BWV 846",
    description: "Performed by Kimiko Ishizaka, public domain.",
    background: "transparent",
    background-color: "#ffffff",
    color: "000000",
    lang: "en",
    embed-local: embed-local-media,
    allow-remote: allow-remote-media,
  )
})

```typ
#audio-svg(
  "https://upload.wikimedia.org/wikipedia/commons/e/e1/Kimiko_Ishizaka_-_Bach_-_Well-Tempered_Clavier,_Book_1_-_02_Fugue_No._1_in_C_major,_BWV_846.ogg",
  width: w,
  height: 60,
  preload: "metadata",
  title: "Bach Fugue No. 1 in C major, BWV 846",
  description: "Performed by Kimiko Ishizaka, public domain.",
  lang: "en",
  embed-local: false,
  allow-remote: true,
)
```

#v(1em)

Local file example:

#audio-svg("/examples/assets/carefree.mp3",
  width: 300,
  height: 60,
  title: "Carefree by Kevin MacLeod",
  description: "Upbeat acoustic instrumental, 3:25, CC BY 4.0.",
  lang: "en",
  embed-local: embed-local-media,
  allow-remote: allow-remote-media,
)

```typ
#audio-svg("/examples/assets/carefree.mp3",
  width: 300,
  height: 60,
  title: "Carefree by Kevin MacLeod",
  description: "Upbeat acoustic instrumental, 3:25, CC BY 4.0.",
  lang: "en",
  embed-local: true,
  allow-remote: true,
)
```