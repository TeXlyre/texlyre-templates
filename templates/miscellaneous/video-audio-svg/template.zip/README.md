# media-svg

Embed playable audio and video in Typst SVG output.

`media-svg` provides two functions:

- `video-svg`: embeds an HTML `<video>` element in SVG output
- `audio-svg`: embeds an HTML `<audio>` element in SVG output

PDF and static outputs show a poster or fallback placeholder instead of playable media.

## Import

<!--
```typ
#import "@preview/media-svg:0.1.0": video-svg, audio-svg
```
-->

For a local checkout:

```typ
#import "/src/lib.typ": video-svg, audio-svg
```

## Media policy

`src` can be a remote URL, a local file path, or a raw `data:` URL.

- `embed-local`: controls local file paths and raw `data:` URLs. Default: `true`.
- `allow-remote`: controls remote `http://` and `https://` URLs. Default: `true`.

When a source is blocked by `embed-local: false` or `allow-remote: false`, the media source is removed and the poster or fallback is shown.

```typ
#let embed-local-media = false
#let allow-remote-media = true
```

## Video

```typ
#video-svg("https://example.com/video.webm",
  width: 640,
  height: 360,
  controls: true,
  loop: true,
  title: "Demo video",
  description: "A short demonstration video.",
  lang: "en",
  embed-local: false,
  allow-remote: true,
)
```

### `video-svg(src, ..)`

Options:

- `width`, `height`: SVG dimensions in pixels. Default: `640`, `360`.
- `controls`: show native playback controls. Default: `true`.
- `autoplay`: start playing on load. Default: `true`. Usually requires `muted: true`.
- `muted`: start muted. Default: `true`.
- `loop`: restart at end. Default: `true`.
- `playsinline`: play inline on iOS. Default: `true`.
- `preload`: `"none"`, `"metadata"`, or `"auto"`. Default: `"auto"`.
- `crossorigin`: CORS mode or `none`. Default: `"anonymous"`.
- `background`: CSS background color for the embedded video element and letterboxing. Default: `"black"`.
- `background-color`: hex color for the posterless fallback placeholder. Default: `"#f0f0f3"`.
- `color`: hex color for the fallback icon and label. Default: `"#444444"`.
- `object-fit`: CSS object fit. Common values are `"cover"`, `"contain"`, `"fill"`, `"none"`, and `"scale-down"`. Default: `"cover"`.
- `poster`: optional poster image path. Default: `none`.
- `poster-link`: poster/fallback link target, `none`, or `auto`. With `auto`, links to `src` only when `src` is remote and `allow-remote` is `true`. Default: `auto`.
- `fallback`: render a static fallback when no poster is set. Also shown when the source is blocked by `embed-local: false` or `allow-remote: false`. Default: `true`.
- `stretch`: overscan in pixels to hide thin encoder edges. Default: `4`.
- `title`: short accessible label. Default: `none`.
- `description`: longer accessible description and PDF alt text. Default: `none`.
- `lang`: BCP 47 language code, such as `"en"` or `"de"`. Default: `none`.
- `embed-local`: allow local file paths and raw `data:` URLs to be embedded. Default: `true`.
- `allow-remote`: allow remote `http://` and `https://` URLs. Default: `true`.

## Audio

```typ
#audio-svg("https://example.com/audio.ogg",
  width: 480,
  height: 60,
  controls: true,
  title: "Demo audio",
  description: "A short demonstration audio clip.",
  lang: "en",
  embed-local: false,
  allow-remote: true,
)
```

### `audio-svg(src, ..)`

Options:

- `width`, `height`: player dimensions in pixels. Default: `320`, `54`.
- `controls`: show native playback controls. Default: `true`.
- `autoplay`: start playing on load. Default: `false`.
- `muted`: start muted. Default: `false`.
- `loop`: restart at end. Default: `false`.
- `preload`: `"none"`, `"metadata"`, or `"auto"`. Default: `"metadata"`.
- `crossorigin`: CORS mode or `none`. Default: `"anonymous"`.
- `background`: CSS background color for the embedded audio wrapper. Default: `"transparent"`.
- `background-color`: hex color for the posterless fallback placeholder. Default: `"#f0f0f3"`.
- `color`: hex color for the fallback icon and label. Default: `"#444444"`.
- `poster`: optional poster image path. Default: `none`.
- `poster-link`: poster/fallback link target, `none`, or `auto`. With `auto`, links to `src` only when `src` is remote and `allow-remote` is `true`. Default: `auto`.
- `fallback`: render a static fallback when no poster is set. Also shown when the source is blocked by `embed-local: false` or `allow-remote: false`. Default: `true`.
- `title`: short accessible label. Default: `none`.
- `description`: longer accessible description and PDF alt text. Default: `none`.
- `lang`: BCP 47 language code, such as `"en"` or `"de"`. Default: `none`.
- `embed-local`: allow local file paths and raw `data:` URLs to be embedded. Default: `true`.
- `allow-remote`: allow remote `http://` and `https://` URLs. Default: `true`.

## Local files and data URLs

Local files are read and inlined as base64 data URLs only when `embed-local` is `true`.

```typ
#video-svg("/examples/assets/flower.mp4",
  width: 640,
  height: 360,
  title: "Flower video",
  description: "Looping demo clip of a flower.",
  lang: "en",
  embed-local: true,
)
```

Prebuilt `data:` URLs are also controlled by `embed-local`:

```typ
#let flower-url = read("/examples/assets/flower.dataurl").trim()

#video-svg(
  flower-url,
  poster: "/examples/assets/fallback-flower.png",
  width: 640,
  height: 360,
  title: "Flower video",
  description: "Looping demo clip of a flower.",
  lang: "en",
  embed-local: true,
)
```

Set `embed-local: false` to remove local file paths and raw `data:` URLs from the generated SVG.

## Compatibility

Playable media requires SVG output rendered in a browser or browser-like environment that preserves embedded SVG/XML media markup.

PDF output and static renderers show only the poster or fallback placeholder. Remote media depends on browser support, network access, MIME type, codec support, CORS behavior, and `allow-remote`.

Local files and raw `data:` URLs depend on `embed-local`.