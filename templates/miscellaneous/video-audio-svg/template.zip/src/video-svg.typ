// video-svg.typ
#import "@preview/based:0.2.0": base64

#let xml_escape(value) = {
  str(value)
    .replace("&", "&amp;")
    .replace("\"", "&quot;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
}

#let attr(name, value) = {
  if value == none {
    ""
  } else {
    " " + name + "=\"" + xml_escape(value) + "\""
  }
}

#let bool_attr(name, enabled) = {
  if enabled {
    " " + name + "=\"" + name + "\""
  } else {
    ""
  }
}

#let is_url(s) = {
  s.starts-with("http://") or s.starts-with("https://")
}

#let mime_for(path) = {
  let ext = lower(path.split(".").last())
  let map = (
    mp4: "video/mp4",
    webm: "video/webm",
    ogv: "video/ogg",
    mov: "video/quicktime",
    mp3: "audio/mpeg",
    ogg: "audio/ogg",
    oga: "audio/ogg",
    opus: "audio/ogg",
    wav: "audio/wav",
    flac: "audio/flac",
    m4a: "audio/mp4",
  )
  map.at(ext, default: "application/octet-stream")
}

#let resolve_src(src, embed-local: true, allow-remote: true) = {
  if is_url(src) {
    if allow-remote { src } else { "" }
  } else if src.starts-with("data:") {
    if embed-local { src } else { "" }
  } else if embed-local {
    "data:" + mime_for(src) + ";base64," + base64.encode(read(src, encoding: none))
  } else {
    ""
  }
}

#let media_placeholder(
  w,
  h,
  kind,
  title,
  description,
  background-color: "#f0f0f3",
  color: "#444444",
) = {
  let label = if title != none {
    title
  } else if kind == "video" {
    "Play video"
  } else {
    "Play audio"
  }

  let icon = if kind == "video" { "▶" } else { "♪" }
  let icon_size = if h < 80pt { 16pt } else { 28pt }
  let label_size = if h < 80pt { 9pt } else { 11pt }

  box(
    width: w,
    height: h,
    fill: rgb(background-color),
    radius: 4pt,
    inset: 0.6em,
    align(center + horizon)[
      #box[
        #text(size: icon_size, fill: rgb(color))[
          #move(dy: -0.08em)[#icon]
        ]
        #std.h(0.5em)
        #text(size: label_size, fill: rgb(color))[#label]
      ]
    ],
  )
}

#let video-svg(
  src,
  width: 640,
  height: 360,
  controls: true,
  autoplay: true,
  muted: true,
  loop: true,
  playsinline: true,
  preload: "auto",
  crossorigin: "anonymous",
  background: "black",
  background-color: "#f0f0f3",
  color: "#444444",
  object-fit: "cover",
  poster: none,
  poster-link: auto,
  fallback: true,
  stretch: 4,
  title: none,
  description: none,
  lang: none,
  embed-local: true,
  allow-remote: true,
) = {
  let sw = xml_escape(width)
  let sh = xml_escape(height)
  let vw = xml_escape(width + stretch)
  let vh = xml_escape(height + stretch)
  let bg = xml_escape(background)
  let raw_url = resolve_src(src, embed-local: embed-local, allow-remote: allow-remote)
  let url = xml_escape(raw_url)
  let media_enabled = raw_url != ""
  let fit = xml_escape(object-fit)

  let link_target = if poster-link == auto {
    if is_url(src) and allow-remote { src } else { none }
  } else {
    poster-link
  }

  let video_attrs = (
    bool_attr("controls", controls),
    bool_attr("autoplay", autoplay),
    bool_attr("muted", muted),
    bool_attr("loop", loop),
    bool_attr("playsinline", playsinline),
    attr("preload", preload),
    attr("crossorigin", crossorigin),
    attr("aria-label", title),
  ).join("")

  let wrapper_style = (
    "margin:0;",
    "padding:0;",
    "border:0;",
    "width:" + sw + "px;",
    "height:" + sh + "px;",
    "overflow:hidden;",
    "background:" + bg + ";",
  ).join("")

  let video_style = (
    "margin:0;",
    "padding:0;",
    "border:0;",
    "display:block;",
    "width:" + vw + "px;",
    "height:" + vh + "px;",
    "object-fit:" + fit + ";",
    "background:" + bg + ";",
  ).join("")

  let background_rect = if poster == none and not fallback {
    "<rect width=\"" + sw + "\" height=\"" + sh + "\" fill=\"" + bg + "\"/>"
  } else {
    ""
  }

  let title_el = if title != none {
    "<title>" + xml_escape(title) + "</title>"
  } else {
    ""
  }

  let desc_el = if description != none {
    "<desc>" + xml_escape(description) + "</desc>"
  } else {
    ""
  }

  let svg = (
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
    "<svg",
    " xmlns=\"http://www.w3.org/2000/svg\"",
    " xmlns:xhtml=\"http://www.w3.org/1999/xhtml\"",
    attr("xml:lang", lang),
    " role=\"img\"",
    attr("aria-label", title),
    " width=\"" + sw + "\"",
    " height=\"" + sh + "\"",
    " viewBox=\"0 0 " + sw + " " + sh + "\"",
    ">",
    title_el,
    desc_el,
    background_rect,
    "<foreignObject x=\"0\" y=\"0\" width=\"" + sw + "\" height=\"" + sh + "\">",
    "<xhtml:div style=\"" + wrapper_style + "\">",
    "<xhtml:video",
    " src=\"" + url + "\"",
    video_attrs,
    " style=\"" + video_style + "\"",
    "/>",
    "</xhtml:div>",
    "</foreignObject>",
    "</svg>",
  ).join("\n")

  let w = width * 1pt
  let h = height * 1pt

  let alt = if description != none {
    description
  } else if title != none {
    title
  } else {
    ""
  }

  let video_layer = if media_enabled {
    image(bytes(svg), format: "svg", width: w, height: h, alt: alt)
  } else {
    none
  }

  let poster_layer = if poster != none {
    image(
      poster,
      width: w,
      height: h,
      fit: "cover",
      alt: alt,
    )
  } else if fallback {
    media_placeholder(
      w,
      h,
      "video",
      title,
      description,
      background-color: background-color,
      color: color,
    )
  } else {
    none
  }

  if video_layer == none {
    poster_layer
  } else if poster_layer == none {
    video_layer
  } else {
    let top_layer = if link_target != none {
      link(link_target, poster_layer)
    } else {
      poster_layer
    }

    box(
      width: w,
      height: h,
      clip: true,
      stack(
        dir: ttb,
        spacing: -h,
        top_layer,
        video_layer,
      ),
    )
  }
}