// video-svg.typ
#import "@preview/based:0.2.0": base64

// Internal build switch.
//
// Public API remains unchanged.
// Modes:
// - "media":  render the SVG foreignObject media layer.
// - "static": render poster/fallback only.
//
// Default is media.
#let media_svg_mode = sys.inputs.at("media-svg-mode", default: "media")

#let xml_escape(value) = {
  str(value)
    .replace("&", "&amp;")
    .replace("\"", "&quot;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
}

#let attr(name, value) = {
  if value == none {
    ""
  } else {
    " " + name + "=\"" + xml_escape(value) + "\""
  }
}

#let bool_attr(name, enabled) = {
  if enabled {
    " " + name + "=\"" + name + "\""
  } else {
    ""
  }
}

#let is_url(s) = {
  s.starts-with("http://") or s.starts-with("https://")
}

#let mime_for(path) = {
  let ext = lower(path.split(".").last())
  let types = (
    mp4: "video/mp4",
    webm: "video/webm",
    ogv: "video/ogg",
    mov: "video/quicktime",

    mp3: "audio/mpeg",
    ogg: "audio/ogg",
    oga: "audio/ogg",
    opus: "audio/ogg",
    wav: "audio/wav",
    flac: "audio/flac",
    m4a: "audio/mp4",

    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    gif: "image/gif",
    webp: "image/webp",
    svg: "image/svg+xml",
  )

  types.at(ext, default: "application/octet-stream")
}

#let resolve_src(src, embed-local: true, allow-remote: true) = {
  if is_url(src) {
    if allow-remote { src } else { "" }
  } else if src.starts-with("data:") {
    if embed-local { src } else { "" }
  } else if embed-local {
    "data:" + mime_for(src) + ";base64," + base64.encode(read(src, encoding: none))
  } else {
    ""
  }
}

#let resolve_poster_src(poster, embed-local: true, allow-remote: true) = {
  if poster == none {
    none
  } else if is_url(poster) {
    if allow-remote { poster } else { none }
  } else if poster.starts-with("data:") {
    if embed-local { poster } else { none }
  } else if embed-local {
    "data:" + mime_for(poster) + ";base64," + base64.encode(read(poster, encoding: none))
  } else {
    none
  }
}

#let placeholder_label(kind, title) = {
  if title != none {
    title
  } else if kind == "video" {
    "Play video"
  } else {
    "Play audio"
  }
}

#let media_placeholder(
  w,
  h,
  kind,
  title,
  background-color: "#f0f0f3",
  color: "#444444",
) = {
  let label = placeholder_label(kind, title)
  let icon = if kind == "video" { "▶" } else { "♪" }
  let icon_size = if h < 80pt { 16pt } else { 28pt }
  let label_size = if h < 80pt { 9pt } else { 11pt }

  box(
    width: w,
    height: h,
    fill: rgb(background-color),
    radius: 4pt,
    inset: 0.6em,
    align(center + horizon)[
      #box[
        #text(size: icon_size, fill: rgb(color))[
          #move(dy: -0.08em)[#icon]
        ]
        #std.h(0.5em)
        #text(size: label_size, fill: rgb(color))[#label]
      ]
    ],
  )
}

#let svg_fallback_placeholder(
  sw,
  sh,
  h,
  kind,
  title,
  background-color: "#f0f0f3",
  color: "#444444",
) = {
  let label = placeholder_label(kind, title)
  let icon = if kind == "video" { "▶" } else { "♪" }
  let icon_size = if h < 80pt { "16" } else { "28" }
  let label_size = if h < 80pt { "9" } else { "11" }

  (
    "<rect",
    " x=\"0\"",
    " y=\"0\"",
    " width=\"" + sw + "\"",
    " height=\"" + sh + "\"",
    " rx=\"4\"",
    " ry=\"4\"",
    " fill=\"" + xml_escape(background-color) + "\"",
    "/>",

    "<text",
    " x=\"50%\"",
    " y=\"46%\"",
    " text-anchor=\"middle\"",
    " dominant-baseline=\"middle\"",
    " font-size=\"" + icon_size + "\"",
    " fill=\"" + xml_escape(color) + "\"",
    ">",
    xml_escape(icon),
    "</text>",

    "<text",
    " x=\"50%\"",
    " y=\"58%\"",
    " text-anchor=\"middle\"",
    " dominant-baseline=\"middle\"",
    " font-size=\"" + label_size + "\"",
    " font-family=\"serif\"",
    " fill=\"" + xml_escape(color) + "\"",
    ">",
    xml_escape(label),
    "</text>",
  ).join("")
}

#let maybe_link(content, href) = {
  if content == none or href == none {
    content
  } else {
    link(href, content)
  }
}

#let invisible_link_layer(w, h, href) = {
  if href == none {
    none
  } else {
    link(
      href,
      box(
        width: w,
        height: h,
        // Creates layout area for the link without drawing over the media.
        fill: rgb("#ffffff").transparentize(100%),
      ),
    )
  }
}

#let video-svg(
  src,
  width: 640,
  height: 360,
  controls: true,
  autoplay: true,
  muted: true,
  loop: true,
  playsinline: true,
  preload: "auto",
  crossorigin: "anonymous",
  background: "black",
  background-color: "#f0f0f3",
  color: "#444444",
  object-fit: "cover",
  poster: none,
  poster-link: auto,
  fallback: true,
  stretch: 4,
  title: none,
  description: none,
  lang: none,
  embed-local: true,
  allow-remote: true,
) = {
  let w = width * 1pt
  let h = height * 1pt

  let sw = xml_escape(width)
  let sh = xml_escape(height)
  let vw = xml_escape(width + stretch)
  let vh = xml_escape(height + stretch)
  let bg = xml_escape(background)

  let raw_url = resolve_src(src, embed-local: embed-local, allow-remote: allow-remote)
  let render_media = media_svg_mode == "media" and raw_url != ""

  let alt = if description != none {
    description
  } else if title != none {
    title
  } else {
    ""
  }

  // `allow-remote` controls media embedding, not whether a poster may link out.
  let link_target = if poster-link == auto {
    if is_url(src) { src } else { none }
  } else {
    poster-link
  }

  let static_layer = {
    let layer = if poster != none {
      image(
        poster,
        width: w,
        height: h,
        fit: "cover",
        alt: alt,
      )
    } else if fallback {
      media_placeholder(
        w,
        h,
        "video",
        title,
        background-color: background-color,
        color: color,
      )
    } else {
      none
    }

    maybe_link(layer, link_target)
  }

  if not render_media {
    static_layer
  } else {
    let url = xml_escape(raw_url)
    let fit = xml_escape(object-fit)

    let raw_poster_url = resolve_poster_src(
      poster,
      embed-local: embed-local,
      allow-remote: allow-remote,
    )

    let video_attrs = (
      bool_attr("controls", controls),
      bool_attr("autoplay", autoplay),
      bool_attr("muted", muted),
      bool_attr("loop", loop),
      bool_attr("playsinline", playsinline),
      attr("preload", preload),
      attr("crossorigin", crossorigin),
      attr("aria-label", title),
    ).join("")

    let wrapper_style = (
      "margin:0;",
      "padding:0;",
      "border:0;",
      "width:" + sw + "px;",
      "height:" + sh + "px;",
      "overflow:hidden;",
      "background:" + bg + ";",
    ).join("")

    let video_style = (
      "margin:0;",
      "padding:0;",
      "border:0;",
      "display:block;",
      "width:" + vw + "px;",
      "height:" + vh + "px;",
      "object-fit:" + fit + ";",
      "background:" + bg + ";",
    ).join("")

    let poster_svg_el = if raw_poster_url != none {
      (
        "<image",
        " href=\"" + xml_escape(raw_poster_url) + "\"",
        " x=\"0\"",
        " y=\"0\"",
        " width=\"" + sw + "\"",
        " height=\"" + sh + "\"",
        " preserveAspectRatio=\"xMidYMid slice\"",
        "/>",
      ).join("")
    } else if fallback {
      svg_fallback_placeholder(
        sw,
        sh,
        h,
        "video",
        title,
        background-color: background-color,
        color: color,
      )
    } else {
      ""
    }

    let background_rect = if raw_poster_url == none and not fallback {
      "<rect width=\"" + sw + "\" height=\"" + sh + "\" fill=\"" + bg + "\"/>"
    } else {
      ""
    }

    let title_el = if title != none {
      "<title>" + xml_escape(title) + "</title>"
    } else {
      ""
    }

    let desc_el = if description != none {
      "<desc>" + xml_escape(description) + "</desc>"
    } else {
      ""
    }

    let svg = (
      "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
      "<svg",
      " xmlns=\"http://www.w3.org/2000/svg\"",
      " xmlns:xhtml=\"http://www.w3.org/1999/xhtml\"",
      attr("xml:lang", lang),
      " role=\"img\"",
      attr("aria-label", title),
      " width=\"" + sw + "\"",
      " height=\"" + sh + "\"",
      " viewBox=\"0 0 " + sw + " " + sh + "\"",
      ">",
      title_el,
      desc_el,
      background_rect,
      poster_svg_el,
      "<foreignObject x=\"0\" y=\"0\" width=\"" + sw + "\" height=\"" + sh + "\">",
      "<xhtml:div style=\"" + wrapper_style + "\">",
      "<xhtml:video",
      " src=\"" + url + "\"",
      video_attrs,
      " style=\"" + video_style + "\"",
      "/>",
      "</xhtml:div>",
      "</foreignObject>",
      "</svg>",
    ).join("\n")

    let media_layer = image(bytes(svg), format: "svg", width: w, height: h, alt: alt)
    let click_layer = invisible_link_layer(w, h, link_target)

    if click_layer == none {
      media_layer
    } else {
      box(
        width: w,
        height: h,
        clip: true,
        stack(
          dir: ttb,
          spacing: -h,
          click_layer,
          media_layer,
        ),
      )
    }
  }
}