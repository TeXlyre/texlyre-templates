// audio-svg.typ
#import "@preview/based:0.2.0": base64

#let xml_escape(value) = {
  str(value)
    .replace("&", "&amp;")
    .replace("\"", "&quot;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
}

#let attr(name, value) = {
  if value == none {
    ""
  } else {
    " " + name + "=\"" + xml_escape(value) + "\""
  }
}

#let bool_attr(name, enabled) = {
  if enabled {
    " " + name + "=\"" + name + "\""
  } else {
    ""
  }
}

#let mime_for(path) = {
  let ext = lower(path.split(".").last())
  let map = (
    mp4: "video/mp4",
    webm: "video/webm",
    ogv: "video/ogg",
    mov: "video/quicktime",
    mp3: "audio/mpeg",
    ogg: "audio/ogg",
    oga: "audio/ogg",
    opus: "audio/ogg",
    wav: "audio/wav",
    flac: "audio/flac",
    m4a: "audio/mp4",
  )
  map.at(ext, default: "application/octet-stream")
}

#let is_url(s) = {
  s.starts-with("http://") or s.starts-with("https://")
}

#let resolve_src(src, embed-local: true, allow-remote: true) = {
  if is_url(src) {
    if allow-remote { src } else { "" }
  } else if src.starts-with("data:") {
    if embed-local { src } else { "" }
  } else if embed-local {
    "data:" + mime_for(src) + ";base64," + base64.encode(read(src, encoding: none))
  } else {
    ""
  }
}

#let media_placeholder(
  w,
  h,
  kind,
  title,
  description,
  background-color: "#f0f0f3",
  color: "#444444",
) = {
  let label = if title != none {
    title
  } else {
    "Play audio"
  }

  let icon = "♪"
  let icon_size = if h < 80pt { 16pt } else { 28pt }
  let label_size = if h < 80pt { 9pt } else { 11pt }

  box(
    width: w,
    height: h,
    fill: rgb(background-color),
    radius: 4pt,
    inset: 0.6em,
    align(center + horizon)[
      #grid(
        columns: (auto, auto),
        column-gutter: 0.5em,
        align: horizon,
        text(size: icon_size, fill: rgb(color))[
          #move(dy: -0.03em)[#icon]
        ],
        text(size: label_size, fill: rgb(color))[#label],
      )
    ],
  )
}

#let audio-svg(
  src,
  width: 320,
  height: 54,
  controls: true,
  autoplay: false,
  muted: false,
  loop: false,
  preload: "metadata",
  crossorigin: "anonymous",
  background: "transparent",
  background-color: "#f0f0f3",
  color: "#444444",
  poster: none,
  poster-link: auto,
  fallback: true,
  title: none,
  description: none,
  lang: none,
  embed-local: true,
  allow-remote: true,
) = {
  let sw = xml_escape(width)
  let sh = xml_escape(height)
  let bg = xml_escape(background)
  let raw_url = resolve_src(src, embed-local: embed-local, allow-remote: allow-remote)
  let url = xml_escape(raw_url)
  let media_enabled = raw_url != ""

  let link_target = if poster-link == auto {
    if is_url(src) and allow-remote { src } else { none }
  } else {
    poster-link
  }

  let audio_attrs = (
    bool_attr("controls", controls),
    bool_attr("autoplay", autoplay),
    bool_attr("muted", muted),
    bool_attr("loop", loop),
    attr("preload", preload),
    attr("crossorigin", crossorigin),
    attr("aria-label", title),
  ).join("")

  let wrapper_style = (
    "margin:0;",
    "padding:0;",
    "border:0;",
    "width:" + sw + "px;",
    "height:" + sh + "px;",
    "overflow:hidden;",
    "background:" + bg + ";",
    "display:flex;",
    "align-items:center;",
    "justify-content:center;",
  ).join("")

  let audio_style = (
    "margin:0;",
    "padding:0;",
    "border:0;",
    "display:block;",
    "width:" + sw + "px;",
    "height:54px;",
  ).join("")

  let background_rect = if poster == none and background != "transparent" {
    "<rect width=\"" + sw + "\" height=\"" + sh + "\" fill=\"" + bg + "\"/>"
  } else {
    ""
  }

  let title_el = if title != none {
    "<title>" + xml_escape(title) + "</title>"
  } else {
    ""
  }

  let desc_el = if description != none {
    "<desc>" + xml_escape(description) + "</desc>"
  } else {
    ""
  }

  let svg = (
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
    "<svg",
    " xmlns=\"http://www.w3.org/2000/svg\"",
    " xmlns:xhtml=\"http://www.w3.org/1999/xhtml\"",
    attr("xml:lang", lang),
    " role=\"img\"",
    attr("aria-label", title),
    " width=\"" + sw + "\"",
    " height=\"" + sh + "\"",
    " viewBox=\"0 0 " + sw + " " + sh + "\"",
    ">",
    title_el,
    desc_el,
    background_rect,
    "<foreignObject x=\"0\" y=\"0\" width=\"" + sw + "\" height=\"" + sh + "\">",
    "<xhtml:div style=\"" + wrapper_style + "\">",
    "<xhtml:audio",
    " src=\"" + url + "\"",
    audio_attrs,
    " style=\"" + audio_style + "\"",
    "/>",
    "</xhtml:div>",
    "</foreignObject>",
    "</svg>",
  ).join("\n")

  let w = width * 1pt
  let h = height * 1pt

  let alt = if description != none {
    description
  } else if title != none {
    title
  } else {
    ""
  }

  let audio_layer = if media_enabled {
    image(bytes(svg), format: "svg", width: w, height: h, alt: alt)
  } else {
    none
  }

  let overlay = if poster != none {
    image(poster, width: w, height: h, fit: "cover", alt: alt)
  } else if fallback {
    media_placeholder(
      w,
      h,
      "audio",
      title,
      description,
      background-color: background-color,
      color: color,
    )
  } else {
    none
  }

  if audio_layer == none {
    overlay
  } else if overlay == none {
    audio_layer
  } else {
    let top_layer = if link_target != none {
      link(link_target, overlay)
    } else {
      overlay
    }

    box(
      width: w,
      height: h,
      clip: true,
      stack(
        dir: ttb,
        spacing: -h,
        top_layer,
        audio_layer,
      ),
    )
  }
}