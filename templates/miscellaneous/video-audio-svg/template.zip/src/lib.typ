#import "/src/video-svg.typ": video-svg
#import "/src/audio-svg.typ": audio-svg

#let video-svg = video-svg
#let audio-svg = audio-svg