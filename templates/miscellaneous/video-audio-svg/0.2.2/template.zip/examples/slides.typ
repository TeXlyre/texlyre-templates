// #import "@preview/media-svg:0.2.2": audio-svg, video-svg
#import "/src/lib.typ": audio-svg, video-svg
#import "@preview/touying:0.7.4": *
#import themes.stargazer: *
#import "@preview/numbly:0.1.0": numbly

#let embed-local-media = true
#let allow-remote-media = true

#show: stargazer-theme.with(
  aspect-ratio: "16-9",
  config-info(
    title: [media-svg],
    subtitle: [Embedding playable media in Typst SVG output],
    author: [Demo],
    date: datetime.today(),
    institution: [Typst],
  ),
  config-common(
    new-section-slide-fn: none,
  ),
)

#set text(font: ("Fira Sans", "Inter"), size: 22pt)
#show heading: set text(font: ("Fira Sans", "Inter"))
#show raw: set text(font: "Fira Code")

#title-slide()

== Overview

`media-svg` is a small Typst package for embedding HTML5 media into SVG output.

#v(0.6em)

- `video-svg`: `<video>` with controls, looping, autoplay, poster, and fallback
- `audio-svg`: `<audio>` with native controls, poster, and fallback
- Sources can be remote URLs, local file paths, or raw `data:` URLs
- `embed-local` controls whether local files are embedded as base64
- `allow-remote` controls whether remote `http://` and `https://` sources are kept

Both functions produce SVG media markup that browsers can hydrate into live media elements.

== Import

//From Typst Universe:

//```typ
//#import "@preview/media-svg:0.2.2": video-svg, audio-svg
//```

From a local checkout of this repository:

```typ
#import "/src/lib.typ": video-svg, audio-svg
```

Example assets live under `examples/assets/`.

== Video

#align(center)[
  #video-svg(
    "https://upload.wikimedia.org/wikipedia/commons/e/e7/Big_buck_bunny_720p_5mb.webm",
    poster: "/examples/assets/fallback-bbbunny.jpg",
    width: 500,
    height: 250,
    autoplay: true,
    muted: true,
    loop: true,
    controls: true,
    preload: "auto",
    title: "Big Buck Bunny clip",
    description: "30-second 720p clip from the Blender Foundation's open animated film.",
    lang: "en",
    embed-local: embed-local-media,
    allow-remote: allow-remote-media,
  )

  #v(0.4em)

  #text(size: 14pt, fill: gray)[
    Big Buck Bunny · Blender Foundation · CC BY-SA 4.0
  ]
]

== Local video

#align(center)[
  #video-svg(
    "/examples/assets/flower.mp4",
    poster: "/examples/assets/fallback-flower.jpg",
    width: 500,
    height: 281,
    autoplay: true,
    muted: true,
    loop: true,
    controls: true,
    preload: "metadata",
    title: "Flower video",
    description: "Looping demo clip of a flower.",
    lang: "en",
    embed-local: embed-local-media,
    allow-remote: allow-remote-media,
  )
]

== Audio

#v(2em)

#align(center)[
  #audio-svg(
    "https://upload.wikimedia.org/wikipedia/commons/e/e1/Kimiko_Ishizaka_-_Bach_-_Well-Tempered_Clavier,_Book_1_-_02_Fugue_No._1_in_C_major,_BWV_846.ogg",
    width: 500,
    height: 40,
    preload: "metadata",
    title: "Bach Fugue No. 1 in C major, BWV 846",
    description: "Performed by Kimiko Ishizaka, public domain (CC0).",
    lang: "en",
    embed-local: embed-local-media,
    allow-remote: allow-remote-media,
  )

  #v(0.6em)

  #text(size: 14pt, fill: gray)[
    Bach · Fugue No. 1 in C major, BWV 846 · Kimiko Ishizaka · CC0
  ]
]

== Local audio

#v(2em)

#align(center)[
  #audio-svg(
    "/examples/assets/carefree.mp3",
    width: 500,
    height: 60,
    preload: "metadata",
    title: "Carefree by Kevin MacLeod",
    description: "Upbeat acoustic instrumental, 3:25, CC BY 4.0.",
    lang: "en",
    embed-local: embed-local-media,
    allow-remote: allow-remote-media,
  )

  #v(0.6em)

  #text(size: 14pt, fill: gray)[
    Carefree · Kevin MacLeod · CC BY 4.0
  ]
]

== Functionality

Both functions wrap an HTML `<video>` or `<audio>` element inside SVG media markup. In compatible SVG/browser output, the browser renders the element with native playback controls.

#v(0.6em)

Requirements:

- SVG output rendered in a browser or browser-like environment
- PDF export shows a static poster or fallback placeholder
- Remote media must be reachable by the browser
- Remote hosts should send permissive CORS headers
- Browser codec support still applies
