#import "@preview/touying:0.6.1": *
#import themes.metropolis: *

#show: metropolis-theme.with(
  aspect-ratio: "16-9",
  config-info(
    title: [TeXlyre, a local-first real-time LaTeX and Typst collaboration platform],
    logo: image("src/logo.svg", height: 1.5em),
  ),
)

#let slide-with-image(image-path, content, image-left: true) = {
  if image-left {
    slide[
      #grid(
        columns: (1fr, 1fr),
        column-gutter: 2em,
        align(horizon, image(image-path, width: 100%)),
        align(horizon, content)
      )
    ]
  } else {
    slide[
      #grid(
        columns: (1fr, 1fr),
        column-gutter: 2em,
        align(horizon, content),
        align(horizon, image(image-path, width: 100%))
      )
    ]
  }
}

#title-slide()

#slide-with-image("/src/undraw_texlyre_engine.svg", [
  = In-Browser LaTeX & Typst Compilation
  
  Compile LaTeX and Typst documents directly in your browser. No server required - SwiftLaTeX (pdfTeX and XeTeX) and Typst.ts WASM builds run on the client-end

], image-left: true)

#slide-with-image("/src/undraw_texlyre_collab.svg", [
  = Real-time Collaboration
  
  Your text content here on the left side.
  TeXlyre enables real-time collaboration with live cursors, peer-to-peer connections, and conflict-free document synchronization using Yjs CRDTs

], image-left: false)

#slide-with-image("/src/undraw_texlyre_privacy.svg", [
  = Local-First Privacy
  
  Your data stays in your browser with TeXlyre's local-first architecture. Work offline, sync when online, and maintain complete control over your documents

], image-left: true)